from project.pokemon import Pokemon


class Trainer:
    def __init__(self, name):
        self.name = name
        self.pokemons = []

    def add_pokemon(self, pokemon):
        if pokemon in self.pokemons:
            return f"This pokemon is already caught"
        else:
            self.pokemons.append(pokemon)
            return f"Caught {pokemon.pokemon_details()}"

    def release_pokemon(self, pokemon_name):
        # сега ще вземем инстанцията от списъка с покемоните горе
        # този филтър прави цикъл през списъка с покемоните и връща резултат ако името на покемона е еднакво на
        # името (забележи не търсим от инстанцията метода, а атрибута) на покемона, който търсим
        # Понеже ако оставим формулата само с филтър ще ни се върне един обект, който няма да ни върши работа
        # слагаме и функцията next, която ще ни върне първия елемент в колекцията. Ако след това го извикаме отново,
        # ще ни върне следващия елемент
        try:
            pokemon = next(filter(lambda p: p.name == pokemon_name, self.pokemons))
        except StopIteration:
            return f"Pokemon is not caught"

        self.pokemons.remove(pokemon)
        return f"You have released {pokemon_name}"

    def trainer_data(self):
        result = []
        result.append(f"Pokemon Trainer {self.name}")
        result.append(f"Pokemon count {len(self.pokemons)}")
        [result.append(f"- {p.pokemon_details()}") for p in self.pokemons]

        return '\n'.join(result)


pokemon = Pokemon("Pikachu", 90)
print(pokemon.pokemon_details())
trainer = Trainer("Ash")
print(trainer.add_pokemon(pokemon))
second_pokemon = Pokemon("Charizard", 110)
print(trainer.add_pokemon(second_pokemon))
print(trainer.add_pokemon(second_pokemon))
print(trainer.release_pokemon("Pikachu"))
print(trainer.release_pokemon("Pikachu"))
print(trainer.trainer_data())
