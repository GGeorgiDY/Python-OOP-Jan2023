from unittest import TestCase, main
from project.mammal import Mammal


class MammalTests(TestCase):

    # Arrange
    def setUp(self):
        self.mammal = Mammal('Sharo', "Dog", "bark")

    # Assert
    def test_initialization(self):
        self.assertEqual(self.mammal.name, 'Sharo')
        self.assertEqual(self.mammal.type, 'Dog')
        self.assertEqual(self.mammal.sound, 'bark')

    def test_make_sound(self):
        self.assertEqual(self.mammal.make_sound(), "Sharo makes bark")

    def test_get_kingdom(self):
        self.assertEqual(self.mammal.get_kingdom(), "animals")

    def test_if_returns_correct_message(self):
        self.assertEqual(self.mammal.info(), "Sharo is of type Dog")


if __name__ == "__main__":
    main()